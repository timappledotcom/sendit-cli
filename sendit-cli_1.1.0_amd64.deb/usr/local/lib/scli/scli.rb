require_relative 'scli/config'
require_relative 'scli/microblog'
require_relative 'scli/x'
require_relative 'scli/nostr'
require_relative 'scli/cli'

module SCLI
  VERSION = '1.1.0'
end
